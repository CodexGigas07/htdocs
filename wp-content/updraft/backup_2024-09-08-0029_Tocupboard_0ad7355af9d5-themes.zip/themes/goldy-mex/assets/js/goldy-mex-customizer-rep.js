jQuery(document).ready(function(){
	// console.log('sortable ready');
    jQuery("ul.sortable").sortable({
      	disabled: true,
    });	

    // jQuery('.sortable').each(function() { 
    //   jQuery(this).sortable('disable'); 
    // });

    // if (jQuery(this).data( "ui-sortable" )) {
    //   jQuery(this).sortable("destroy");
    // }
});
<?php 
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package goldy-mex
 */
global $goldy_mex_default;

 ?>
 	<div class="appointment_section_info">
 		<?php do_action('goldy_book_an_appointment_section_data', $goldy_mex_default); ?>
 	</div>
<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package goldy-mex
 */
?>
<div class="goldy_mex_widget_section">
	<div class="goldy_mex_widget_inner_data">
		<?php dynamic_sidebar('goldy-mex-widget-section'); ?>
	</div>
</div>
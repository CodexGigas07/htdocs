<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package goldy-mex
 */
global $goldy_mex_default;
	?>
	<div class="about_section_info">
		<div class="about_data">
			<?php do_action('goldy_about_section_data', $goldy_mex_default); ?>
		</div>
	</div>